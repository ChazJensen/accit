/* Title:				Basic Story Creator
 * Author:			Christian Johnson
 * Note:				Pictures created with https://sketch.io/sketchpad/
 * 								pictures drawn by Christian Johnson
 *
 * Description:	A program that makes a story based on an array of "pages". 
 * 							Each page is determined by an entry into the storyText constant array.
 *
 * Use:					For each page you wish to create, add an additional, well-formatted string
 *							to the story text array below and a picture named <pageNumber>.png to the img
 *							folder in the main directory. There is only 1 picture per page allowed at the
 * 							moment. Additionally,  the story must include a "split-path" point that occurs
 *							correlating to the last two pictures and an end card. The two strings in storyText
 *							before the final string indicate the location of the split-path, only one of
 *							them will be seen during each revolution of the story. The buttons that apear to
 *							direct the program to which one to view must be named, replace the strings of
 *							constants OPT_1_TEXT and OPT_2_TEXT with what you would like the buttons to say.
 */

const storyText = [
	"This is Bob.",
	"Bob is plain.",
	"Bob decided to eat some crayons.",
	"Bob is now colorful.",
	"But Bob ate too many purple crayons,",
	"Should Bob try to fix it?",
	"He decided to eat a lot of yellow crayons to balance out the purple crayons.",
	"He decided that he was okay being purple.",
	"The End!"
];

const OPT_1_TEXT = "Yes!";
const OPT_2_TEXT = "Nah, he's cool the way he is";

const STORY_LENGTH = storyText.length - 1;
const CHOICE_PAGE = STORY_LENGTH - 3;
const OPT_1 = STORY_LENGTH - 2;
const OPT_2 = STORY_LENGTH - 1;





















//========== Variables ===========================================================================

// list of buttons made throughout the program
var btnList = [];

// array for pictures
var pictures = [];

// current page number
var pageNumber = 0;

// element in webpage
var textEl = document.getElementById("text");

var textUpdate = () => {
	textEl.textContent = storyText[pageNumber];
}

//========== DOM Interactivity ===========================================================================

// main section of webpage
const main = document.getElementById("main");

// story frame of project
const story = document.getElementById("story");

// names of buttons sorted by declaration
const btnNameList = [
	"Previous Page",
	"Next Page",
	OPT_1_TEXT,
	OPT_2_TEXT,
	"Turn Page",
	"Reread"
];
//========== Button Functionality =========================================================================


// TODO: update click functions to include two options, an end screen, and altered btn text.


// navigation buttons
const btnBack = new Button(btnNameList[0], () => {
	// function for clicking "previous page"
	if (pageNumber > 0) {
		--pageNumber;
	}
	
	
	// updates
	Button.update();
	Picture.update();
	textUpdate();
});

const btnNext = new Button(btnNameList[1], () => {
	// function for clicking "next page"
	if (pageNumber < STORY_LENGTH) {	// default true
		++pageNumber;
	} else {													// reset
		pageNumber = 0;
	}
	
	
	// updates
	Button.update();
	Picture.update();
	textUpdate();
});

const btnEat = new Button(btnNameList[2], () => {
	pageNumber = STORY_LENGTH - 2;
	// updates
	Button.update();
	Picture.update();
	textUpdate();
});

const btnFast = new Button(btnNameList[3], () => {
	pageNumber = STORY_LENGTH - 1;
	// updates
	Button.update();
	Picture.update();
	textUpdate();
});

const btnEnd = new Button(btnNameList[4], () => {
	pageNumber = STORY_LENGTH;
	// updates
	Button.update();
	Picture.update();
	textUpdate();
});

const btnReset = new Button(btnNameList[5], () => {
	pageNumber = 0;
	// updates
	Button.update();
	Picture.update();
	textUpdate();
});

//========== Set Up ===========================================================================

// setup
window.onload = () => {
	// put buttons in a group
	// div to make group
	let btnDiv = document.createElement("div");
	
	// puts buttons in group
	btnDiv = Button.setup(btnDiv, btnList);
	
	// display buttons
	main.appendChild(btnDiv);
	
	// updates
	Button.update();
	Picture.setup(storyText);
	textUpdate();
};