/* Title:				Basic Story Creator
 * Author:			Christian Johnson
 * Note:				Pictures created with https://sketch.io/sketchpad/
 * 								pictures drawn by Christian Johnson
 *
 * Description:	Module for storybook program
*/

class Picture {
	constructor(src, alt) {
		this.src = src;
		this.alt = alt;
	}
}


Picture.setup = lines => {
	for (lineNum in lines) {
		// add a picture to the pictures array for each string in theStoryText array (each image must be a png and have the page number, index 0, as its name)
		pictures.push(new Picture("img/" + lineNum + ".png", lines[lineNum]));
	}
	Picture.update();
};

// update picture to match the page number
Picture.update = () => {
	story.src = pictures[pageNumber].src;
	textUpdate();
};