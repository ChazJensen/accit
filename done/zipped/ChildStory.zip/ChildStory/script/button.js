/* Title:				Basic Story Creator
 * Author:			Christian Johnson
 * Note:				Pictures created with https://sketch.io/sketchpad/
 * 								pictures drawn by Christian Johnson
 *
 * Description:	Module for storybook program
*/

class Button {
	constructor(name, onClick = (btn, btnList) => {console.log(btn.name);}) {
		// super("button");
		this.name = name;
		this.func = onClick;
		
		
		this.el = document.createElement("button");
		this.el.appendChild(document.createTextNode(this.name));
		// full credit to line below goes to : ibrahim mahrir @ https://stackoverflow.com/questions/43727516/javascript-how-adding-event-handler-inside-a-class-with-a-class-method-as-the-c/43727582
		this.el.addEventListener("click", ev => this.func(this)); 
		
		Button.addToList(btnList, this);
	}
}

Button.setup = (btnDiv, btnList) => {
	// put buttons in group
	btnDiv.setAttribute("id", "btnDiv");
	for (btnObj in btnList) {
		let btn = btnList[btnObj];
		// put button in div
		btnDiv.appendChild(btn.el);
		if (btnObj > 1) {
			btn.el.style.display = "none";
		}
	}
	return btnDiv
}

Button.noneBut = arr => {
	for (index in btnList) {
		if (arr.includes(btnList[index].name)) {
			btnList[index].el.style.display = "inline";
		} else {
			btnList[index].el.style.display = "none";
		}
	}
};

Button.toggleDisplay = btn => {
	if (btnList[btn].el.style.display == "inline") {
		btnList[btn].el.style.display = "block";
		btnList[btn].el.style.marginLeft = "auto";
		btnList[btn].el.style.marginRight = "auto";
	} else {
		btnList[btn].el.style.display = "inline";
	}
}

Button.update = () => {
	// set btnBack to display: none;
	if (pageNumber == 0) {
		Button.noneBut(["Next Page"]);
	} else if (pageNumber == CHOICE_PAGE - 1) {
		Button.noneBut(["Next Page", "Previous Page"])
	} else if (pageNumber == CHOICE_PAGE) {
		Button.noneBut(["Previous Page", OPT_1_TEXT, OPT_2_TEXT]);
		Button.toggleDisplay(0);
	} else if (pageNumber == OPT_1 || pageNumber == OPT_2) {
		Button.noneBut(["Turn Page"]);
	} else if (pageNumber == STORY_LENGTH) {
		Button.noneBut(["Reread"])
	} else
		{btnBack.el.style.display = "inline";}
}

Button.addToList = (list, btn) => {
	list.push(btn);
};